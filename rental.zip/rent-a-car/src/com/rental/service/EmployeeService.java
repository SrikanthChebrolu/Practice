package com.rental.service;

public interface EmployeeService {

}
